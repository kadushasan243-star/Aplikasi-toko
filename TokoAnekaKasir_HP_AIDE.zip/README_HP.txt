KASIR TOKO ANEKA — VERSI BUILD DARI HP

Proyek ini disiapkan khusus agar lebih mudah dibuka/build menggunakan AIDE di Android.
Tidak membutuhkan laptop.

Fitur:
- Produk dan stok
- Cari nama/barcode
- Tambah/kurangi jumlah
- Total belanja
- Pembayaran & kembalian
- Laporan transaksi & omzet lokal
- Struk dan Bagikan
- Menu scanner/printer sebagai persiapan

CARA BUILD DI HP DENGAN AIDE
1. Instal AIDE dari sumber resminya.
2. Ekstrak ZIP ini ke penyimpanan HP, misalnya:
   /Download/TokoAnekaKasir_HP
3. Buka AIDE.
4. Pilih Open/Import Existing Project.
5. Pilih folder TokoAnekaKasir_HP.
6. Jika AIDE meminta SDK/target, pilih API yang tersedia.
7. Pilih Run untuk build dan memasang APK.
8. Jika muncul permintaan izin instalasi dari sumber tidak dikenal,
   izinkan AIDE/file manager yang digunakan untuk memasang APK.

CATATAN
- Proyek ini memakai Java/XML sederhana agar ringan.
- Tidak memakai library eksternal.
- Data barang, transaksi, dan omzet disimpan lokal di HP.
- Kamera barcode dan printer thermal belum aktif penuh pada versi ini.
