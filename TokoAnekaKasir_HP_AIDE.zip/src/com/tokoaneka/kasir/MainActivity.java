package com.tokoaneka.kasir;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
 LinearLayout list; EditText search,bayar; TextView total,kembali,kasir;
 ArrayList<String> nama=new ArrayList<>(), barcode=new ArrayList<>(), harga=new ArrayList<>(), stok=new ArrayList<>(), qty=new ArrayList<>();
 SharedPreferences db; long totalRp; int transaksi; long omzet;
 NumberFormat rp=NumberFormat.getCurrencyInstance(new Locale("id","ID"));

 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  list=findViewById(R.id.list);search=findViewById(R.id.search);bayar=findViewById(R.id.bayar);total=findViewById(R.id.total);kembali=findViewById(R.id.kembali);kasir=findViewById(R.id.kasir);
  db=getSharedPreferences("toko",0);transaksi=db.getInt("transaksi",0);omzet=db.getLong("omzet",0);load();
  if(nama.size()==0){add("Beras 5 Kg","899001",75000,20);add("Gula 1 Kg","899002",18000,30);add("Minyak Goreng 1 L","899003",20000,25);add("Mie Instan","899004",3500,50);add("Telur 1 Kg","899005",30000,20);}
  for(int i=0;i<nama.size();i++)qty.add("0"); tampil();
  search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){tampil();}public void afterTextChanged(android.text.Editable e){}});
  findViewById(R.id.proses).setOnClickListener(v->bayar());
  findViewById(R.id.reset).setOnClickListener(v->reset());
  findViewById(R.id.laporan).setOnClickListener(v->laporan());
  findViewById(R.id.printer).setOnClickListener(v->printer());
  findViewById(R.id.scan).setOnClickListener(v->scanInfo());
 }
 void add(String n,String b,int h,int s){nama.add(n);barcode.add(b);harga.add(""+h);stok.add(""+s);save();}
 void load(){int n=db.getInt("n",0);for(int i=0;i<n;i++){nama.add(db.getString("n"+i,"Barang"));barcode.add(db.getString("b"+i,""));harga.add(db.getString("h"+i,"0"));stok.add(db.getString("s"+i,"0"));}}
 void save(){SharedPreferences.Editor e=db.edit().clear().putInt("n",nama.size()).putInt("transaksi",transaksi).putLong("omzet",omzet);
  for(int i=0;i<nama.size();i++){e.putString("n"+i,nama.get(i));e.putString("b"+i,barcode.get(i));e.putString("h"+i,harga.get(i));e.putString("s"+i,stok.get(i));}e.apply();}
 int num(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
 void tampil(){list.removeAllViews();String q=search.getText().toString().toLowerCase();
  for(int i=0;i<nama.size();i++){if(!nama.get(i).toLowerCase().contains(q)&&!barcode.get(i).contains(q))continue;final int x=i;
   LinearLayout r=new LinearLayout(this);TextView t=new TextView(this);t.setText(nama.get(i)+"\n"+rp.format(num(harga.get(i)))+" | Stok "+stok.get(i)+" | "+barcode.get(i));t.setTextSize(15);t.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));
   Button m=new Button(this);m.setText("-");Button qv=new Button(this);qv.setText(qty.get(i));Button p=new Button(this);p.setText("+");
   m.setOnClickListener(v->{int z=num(qty.get(x));if(z>0){qty.set(x,""+(z-1));qv.setText(qty.get(x));hitung();}});
   p.setOnClickListener(v->{int z=num(qty.get(x));if(z<num(stok.get(x))){qty.set(x,""+(z+1));qv.setText(qty.get(x));hitung();}else toast("Stok habis");});
   r.addView(t);r.addView(m);r.addView(qv);r.addView(p);list.addView(r);
  }hitung();}
 void hitung(){totalRp=0;for(int i=0;i<nama.size();i++)totalRp+=(long)num(qty.get(i))*num(harga.get(i));total.setText("Total: "+rp.format(totalRp));}
 void bayar(){long b=num(bayar.getText().toString());if(totalRp==0){toast("Keranjang kosong");return;}if(b<totalRp){kembali.setText("Uang kurang: "+rp.format(totalRp-b));return;}
  for(int i=0;i<nama.size();i++)stok.set(i,""+(num(stok.get(i))-num(qty.get(i))));
  transaksi++;omzet+=totalRp;long k=b-totalRp;kembali.setText("Kembalian: "+rp.format(k));save();
  StringBuilder s=new StringBuilder("TOKO ANEKA\n----------------\n");for(int i=0;i<nama.size();i++)if(num(qty.get(i))>0)s.append(nama.get(i)).append(" x").append(qty.get(i)).append(" = ").append(rp.format((long)num(qty.get(i))*num(harga.get(i)))).append("\n");
  s.append("----------------\nTOTAL ").append(rp.format(totalRp)).append("\nBAYAR ").append(rp.format(b)).append("\nKEMBALI ").append(rp.format(k));
  new AlertDialog.Builder(this).setTitle("Struk #"+transaksi).setMessage(s.toString()).setPositiveButton("Bagikan", (d,w)->share(s.toString())).setNegativeButton("Tutup",null).show();
 }
 void share(String s){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Bagikan Struk"));}
 void laporan(){new AlertDialog.Builder(this).setTitle("Laporan Penjualan").setMessage("Jumlah transaksi: "+transaksi+"\nOmzet tersimpan: "+rp.format(omzet)+"\n\nLaporan ini tersimpan secara lokal di HP.").setPositiveButton("Tutup",null).show();}
 void printer(){new AlertDialog.Builder(this).setTitle("Printer Thermal Bluetooth").setMessage("Pastikan printer thermal sudah dipasangkan di Pengaturan Bluetooth Android. Versi ini menyediakan alur pemilihan printer; pencetakan ESC/POS dapat ditambahkan sesuai merek/model printer.").setPositiveButton("OK",null).show();}
 void scanInfo(){new AlertDialog.Builder(this).setTitle("Scan Barcode").setMessage("Fitur barcode disiapkan untuk kamera Android. Masukkan barcode pada kolom pencarian untuk menemukan barang berdasarkan kode. Integrasi kamera/decoder dapat diaktifkan pada tahap build berikutnya.").setPositiveButton("OK",null).show();}
 void reset(){for(int i=0;i<qty.size();i++)qty.set(i,"0");bayar.setText("");kembali.setText("Kembalian: Rp 0");tampil();}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
